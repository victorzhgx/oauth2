
INSERT INTO product (id, available,  name, version) VALUES (1, 0,'product_1', 0);
INSERT INTO product (id, available,  name, version) VALUES (2, 1,'product_2', 0);